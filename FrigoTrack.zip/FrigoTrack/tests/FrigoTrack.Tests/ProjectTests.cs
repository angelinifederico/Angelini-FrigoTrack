using System.Net;
using System.Net.Http.Json;
using System.Security.Cryptography;
using Xunit;
using FrigoTrack.Common;
using Microsoft.AspNetCore.Mvc.Testing;

namespace FrigoTrack.Tests;

public class ProjectTests
{
    [Fact]
    public void Handshake_DhProduceSameSharedKey()
    {
        var a = DiffieHellman.CreateKeyPair();
        var b = DiffieHellman.CreateKeyPair();
        var ka = DiffieHellman.DeriveAesKey(DiffieHellman.ComputeSharedSecret(b.Public, a.Private));
        var kb = DiffieHellman.DeriveAesKey(DiffieHellman.ComputeSharedSecret(a.Public, b.Private));
        Assert.Equal(ka, kb);
    }

    [Fact]
    public void Encryption_ValidMessageCanBeDecrypted()
    {
        byte[] key = RandomNumberGenerator.GetBytes(32);
        var original = new TelemetryMessage("CELLA-BG-007", DateTimeOffset.UtcNow, "pharma", 4.5);
        var envelope = CryptoBox.Encrypt("test-session", original, key);
        var decoded = CryptoBox.DecryptAs<TelemetryMessage>(envelope, key);
        Assert.Equal(original.SensorId, decoded.SensorId);
        Assert.Equal(original.TemperatureC, decoded.TemperatureC);
    }

    [Fact]
    public void TamperedEnvelope_IsRejected()
    {
        byte[] key = new byte[32];
        var envelope = CryptoBox.Encrypt("test-session", new { value = 123 }, key);
        var changed = envelope with { Ciphertext = Convert.ToBase64String(new byte[] { 1, 2, 3 }) };
        Assert.ThrowsAny<System.Security.Cryptography.CryptographicException>(() => CryptoBox.Decrypt(changed, key));
    }

    [Fact]
    public void Schema_AcceptsValidTelemetry()
    {
        var validator = new SchemaValidator(Path.Combine(AppContext.BaseDirectory, "schemas"));
        var message = new TelemetryMessage("CELLA-BG-007", DateTimeOffset.UtcNow, "pharma", 4.6, 55, 87);
        Assert.True(validator.Validate("telemetry", message).IsValid);
    }

    [Fact]
    public void Schema_RejectsOutOfRangeTemperature()
    {
        var validator = new SchemaValidator(Path.Combine(AppContext.BaseDirectory, "schemas"));
        var message = new TelemetryMessage("CELLA-BG-007", DateTimeOffset.UtcNow, "pharma", 100);
        Assert.False(validator.Validate("telemetry", message).IsValid);
    }

    [Fact]
    public async Task MissingSession_Returns401()
    {
        await using var factory = new WebApplicationFactory<Program>();
        using var client = factory.CreateClient();
        var envelope = new CryptoEnvelope("00000000000000000000000000000000",
            Convert.ToBase64String(new byte[12]), Convert.ToBase64String(new byte[1]),
            Convert.ToBase64String(new byte[16]));
        using var response = await client.PostAsJsonAsync("/api/telemetry", envelope, JsonDefaults.Options);
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }
}
