using System.Text.Json.Serialization;

namespace FrigoTrack.Common;

public sealed record HandshakeRequest(string P, string G, string A);
public sealed record HandshakeResponse(string SessionId, string B);
public sealed record CryptoEnvelope(string SessionId, string Nonce, string Ciphertext, string Tag);
public sealed record TelemetryMessage(string SensorId, DateTimeOffset Timestamp, string CargoType,
    double TemperatureC, double? Humidity = null, int? Battery = null);
public sealed record ReadingsRequest(string SensorId, DateTimeOffset? From = null, DateTimeOffset? To = null);
public sealed record ReadingsResponse(string SensorId, List<TelemetryMessage> Readings);
public sealed record ApiError(string Error, string? Field = null);
public sealed record AckResponse(string Status, string SensorId, bool Alarm, string? AlarmMessage = null);
