using System.Text.Json;
using System.Text.Json.Nodes;
using Json.Schema;

namespace FrigoTrack.Common;

public sealed class SchemaValidator
{
    private readonly string _schemaDirectory;
    private readonly Dictionary<string, JsonSchema> _cache = new(StringComparer.OrdinalIgnoreCase);

    public SchemaValidator(string schemaDirectory) => _schemaDirectory = schemaDirectory;

    public (bool IsValid, string? Error) Validate<T>(string schemaName, T value)
    {
        string path = Path.Combine(_schemaDirectory, schemaName + ".schema.json");
        if (!File.Exists(path)) return (false, $"Schema non trovato: {path}");
        if (!_cache.TryGetValue(schemaName, out var schema))
        {
            schema = JsonSchema.FromText(File.ReadAllText(path));
            _cache[schemaName] = schema;
        }

        JsonNode? node = JsonSerializer.SerializeToNode(value, JsonDefaults.Options);
        var result = schema.Evaluate(node);
        return result.IsValid ? (true, null) : (false, result.ToString());
    }
}
