using System.Net.Http.Json;
using System.Numerics;
using System.Text.Json;
using FrigoTrack.Common;

const string baseUrl = "http://localhost:5080";
using var http = new HttpClient { BaseAddress = new Uri(baseUrl), Timeout = TimeSpan.FromSeconds(15) };
var validator = new SchemaValidator(Path.Combine(AppContext.BaseDirectory, "schemas"));
bool once = args.Contains("--once");
bool invalidDemo = args.Contains("--invalid");

string[] sensors = ["CELLA-BG-007", "CAMION-MI-012", "CELLA-RM-003"];
var sessions = new Dictionary<string, (string Id, byte[] Key)>();

Console.WriteLine("FrigoTrack Client - simulatore di 3 sensori");
foreach (string sensor in sensors)
{
    var pair = DiffieHellman.CreateKeyPair();
    var request = new HandshakeRequest(DiffieHellman.PDecimal, DiffieHellman.GDecimal, pair.Public.ToString());
    var check = validator.Validate("handshake-request", request);
    if (!check.IsValid) throw new InvalidOperationException(check.Error);
    using var response = await http.PostAsJsonAsync("/api/handshake", request, JsonDefaults.Options);
    response.EnsureSuccessStatusCode();
    var handshake = await response.Content.ReadFromJsonAsync<HandshakeResponse>(JsonDefaults.Options)
        ?? throw new InvalidOperationException("Risposta handshake vuota.");
    var b = DiffieHellman.ParseDecimal(handshake.B);
    byte[] key = DiffieHellman.DeriveAesKey(DiffieHellman.ComputeSharedSecret(b, pair.Private));
    sessions[sensor] = (handshake.SessionId, key);
    Console.WriteLine($"Handshake completato: {sensor} (sessione {handshake.SessionId})");
}

do
{
    foreach (string sensor in sensors)
    {
        var (sessionId, key) = sessions[sensor];
        var message = new TelemetryMessage(sensor, DateTimeOffset.UtcNow, sensor.Contains("CAMION") ? "food" : "pharma",
            sensor == "CELLA-RM-003" ? 10.5 : 4.6, 55, 87);
        if (invalidDemo && sensor == sensors[0])
            message = message with { TemperatureC = 100 };

        var validation = validator.Validate("telemetry", message);
        if (!validation.IsValid)
        {
            Console.WriteLine($"[CLIENT] {sensor}: misura bloccata prima della cifratura: {validation.Error}");
            continue;
        }

        var envelope = CryptoBox.Encrypt(sessionId, message, key);
        using var response = await http.PostAsJsonAsync("/api/telemetry", envelope, JsonDefaults.Options);
        if (!response.IsSuccessStatusCode)
        {
            Console.WriteLine($"Errore HTTP {(int)response.StatusCode}: {await response.Content.ReadAsStringAsync()}");
            continue;
        }
        var ackEnvelope = await response.Content.ReadFromJsonAsync<CryptoEnvelope>(JsonDefaults.Options)
            ?? throw new InvalidOperationException("Ack vuoto.");
        var ack = CryptoBox.DecryptAs<AckResponse>(ackEnvelope, key);
        Console.WriteLine($"{sensor}: {ack.Status}; temperatura={message.TemperatureC} °C; allarme={ack.Alarm}");
        if (ack.Alarm) Console.WriteLine($"  ALLARME: {ack.AlarmMessage}");
    }

    if (once) break;
    await Task.Delay(TimeSpan.FromSeconds(5));
} while (true);

// Lettura dimostrativa per il primo sensore.
var first = sensors[0];
var (sid, sessionKey) = sessions[first];
var readRequest = new ReadingsRequest(first);
var readEnvelope = CryptoBox.Encrypt(sid, readRequest, sessionKey);
using (var readResponse = await http.PostAsJsonAsync("/api/readings", readEnvelope, JsonDefaults.Options))
{
    readResponse.EnsureSuccessStatusCode();
    var encrypted = await readResponse.Content.ReadFromJsonAsync<CryptoEnvelope>(JsonDefaults.Options)
        ?? throw new InvalidOperationException("Risposta letture vuota.");
    var readings = CryptoBox.DecryptAs<ReadingsResponse>(encrypted, sessionKey);
    Console.WriteLine($"Letture archiviate per {first}: {readings.Readings.Count}");
}

// Chiude tutte le sessioni.
foreach (var (sessionId, key) in sessions.Values)
{
    var closeEnvelope = CryptoBox.Encrypt(sessionId, new { confirm = true }, key);
    using var closeResponse = await http.PostAsJsonAsync("/api/close", closeEnvelope, JsonDefaults.Options);
    Console.WriteLine($"Chiusura sessione {sessionId}: {(int)closeResponse.StatusCode}");
}
