using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace FrigoTrack.Common;

public static class CryptoBox
{
    public static CryptoEnvelope Encrypt<T>(string sessionId, T value, byte[] key)
    {
        byte[] nonce = RandomNumberGenerator.GetBytes(12);
        byte[] plain = JsonSerializer.SerializeToUtf8Bytes(value, JsonDefaults.Options);
        byte[] cipher = new byte[plain.Length];
        byte[] tag = new byte[16];
        using var aes = new AesGcm(key, 16);
        aes.Encrypt(nonce, plain, cipher, tag, Encoding.UTF8.GetBytes(sessionId));
        return new(sessionId, Convert.ToBase64String(nonce),
            Convert.ToBase64String(cipher), Convert.ToBase64String(tag));
    }

    public static byte[] Decrypt(CryptoEnvelope envelope, byte[] key)
    {
        byte[] nonce = Convert.FromBase64String(envelope.Nonce);
        byte[] cipher = Convert.FromBase64String(envelope.Ciphertext);
        byte[] tag = Convert.FromBase64String(envelope.Tag);
        if (nonce.Length != 12 || tag.Length != 16) throw new CryptographicException("Nonce o tag non validi.");
        byte[] plain = new byte[cipher.Length];
        using var aes = new AesGcm(key, 16);
        aes.Decrypt(nonce, cipher, tag, plain, Encoding.UTF8.GetBytes(envelope.SessionId));
        return plain;
    }

    public static T DecryptAs<T>(CryptoEnvelope envelope, byte[] key)
    {
        byte[] plain = Decrypt(envelope, key);
        return JsonSerializer.Deserialize<T>(plain, JsonDefaults.Options)
            ?? throw new JsonException("Contenuto JSON vuoto.");
    }
}
