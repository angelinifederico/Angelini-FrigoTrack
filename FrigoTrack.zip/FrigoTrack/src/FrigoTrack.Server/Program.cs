using System.Collections.Concurrent;
using System.Numerics;
using System.Text.Json;
using FrigoTrack.Common;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://localhost:5080");
var app = builder.Build();

string schemaPath = Path.Combine(AppContext.BaseDirectory, "schemas");
var validator = new SchemaValidator(schemaPath);
var sessions = new ConcurrentDictionary<string, SessionState>();
string dataDirectory = Path.Combine(AppContext.BaseDirectory, "data");
Directory.CreateDirectory(dataDirectory);
var fileLocks = new ConcurrentDictionary<string, SemaphoreSlim>();

app.MapPost("/api/handshake", (HandshakeRequest request) =>
{
    var schema = validator.Validate("handshake-request", request);
    if (!schema.IsValid) return Results.BadRequest(new ApiError("Handshake non valido", schema.Error));

    try
    {
        BigInteger p = DiffieHellman.ParseDecimal(request.P);
        BigInteger g = DiffieHellman.ParseDecimal(request.G);
        BigInteger aPublic = DiffieHellman.ParseDecimal(request.A);
        if (p != DiffieHellman.P || g != DiffieHellman.G ||
            aPublic <= 1 || aPublic >= p - 1)
            return Results.BadRequest(new ApiError("Parametri DH non ammessi."));

        var (privateKey, publicKey) = DiffieHellman.CreateKeyPair();
        byte[] key = DiffieHellman.DeriveAesKey(
            DiffieHellman.ComputeSharedSecret(aPublic, privateKey));
        string sessionId = Guid.NewGuid().ToString("N");
        sessions[sessionId] = new SessionState(key);
        var response = new HandshakeResponse(sessionId, publicKey.ToString());
        var valid = validator.Validate("handshake-response", response);
        return valid.IsValid ? Results.Ok(response) : Results.Problem("Errore interno schema handshake.");
    }
    catch (Exception ex) when (ex is FormatException or System.Security.Cryptography.CryptographicException)
    {
        return Results.BadRequest(new ApiError("Parametri DH non validi."));
    }
});

app.MapPost("/api/telemetry", async (CryptoEnvelope envelope) =>
{
    if (!sessions.TryGetValue(envelope.SessionId, out var session))
        return Results.Unauthorized();
    TelemetryMessage message;
    try { message = CryptoBox.DecryptAs<TelemetryMessage>(envelope, session.Key); }
    catch (Exception ex) when (ex is FormatException or System.Security.Cryptography.CryptographicException or JsonException)
    { return Results.BadRequest(new ApiError("Busta non valida o manomessa.")); }

    var validation = validator.Validate("telemetry", message);
    if (!validation.IsValid)
        return Results.BadRequest(new ApiError("Misura non valida secondo JSON Schema", validation.Error));

    string file = Path.Combine(dataDirectory, SafeFileName(message.SensorId) + ".json");
    var gate = fileLocks.GetOrAdd(file, _ => new SemaphoreSlim(1, 1));
    await gate.WaitAsync();
    try
    {
        List<TelemetryMessage> readings = File.Exists(file)
            ? JsonSerializer.Deserialize<List<TelemetryMessage>>(await File.ReadAllTextAsync(file), JsonDefaults.Options) ?? []
            : [];
        readings.Add(message);
        await File.WriteAllTextAsync(file, JsonSerializer.Serialize(readings, JsonDefaults.Options));
    }
    finally { gate.Release(); }

    bool alarm = message.CargoType switch
    {
        "pharma" => message.TemperatureC < 2 || message.TemperatureC > 8,
        "food" => message.TemperatureC < 0 || message.TemperatureC > 8,
        "frozen" => message.TemperatureC > -18,
        _ => false
    };
    string? alarmText = alarm ? $"Temperatura fuori intervallo per merce {message.CargoType}." : null;
    var ack = new AckResponse("ok", message.SensorId, alarm, alarmText);
    return Results.Ok(CryptoBox.Encrypt(envelope.SessionId, ack, session.Key));
});

app.MapPost("/api/readings", (CryptoEnvelope envelope) =>
{
    if (!sessions.TryGetValue(envelope.SessionId, out var session))
        return Results.Unauthorized();
    ReadingsRequest request;
    try { request = CryptoBox.DecryptAs<ReadingsRequest>(envelope, session.Key); }
    catch (Exception ex) when (ex is FormatException or System.Security.Cryptography.CryptographicException or JsonException)
    { return Results.BadRequest(new ApiError("Busta non valida o manomessa.")); }

    var validation = validator.Validate("readings-request", request);
    if (!validation.IsValid)
        return Results.BadRequest(new ApiError("Richiesta non valida", validation.Error));

    string file = Path.Combine(dataDirectory, SafeFileName(request.SensorId) + ".json");
    List<TelemetryMessage> readings = File.Exists(file)
        ? JsonSerializer.Deserialize<List<TelemetryMessage>>(File.ReadAllText(file), JsonDefaults.Options) ?? []
        : [];
    var filtered = readings.Where(r =>
        (!request.From.HasValue || r.Timestamp >= request.From) &&
        (!request.To.HasValue || r.Timestamp <= request.To)).ToList();
    var response = new ReadingsResponse(request.SensorId, filtered);
    var responseValidation = validator.Validate("readings-response", response);
    if (!responseValidation.IsValid) return Results.Problem("Errore interno nello schema della risposta.");
    return Results.Ok(CryptoBox.Encrypt(envelope.SessionId, response, session.Key));
});

app.MapPost("/api/close", (CryptoEnvelope envelope) =>
{
    if (!sessions.TryGetValue(envelope.SessionId, out var session))
        return Results.Unauthorized();
    try
    {
        using var doc = JsonDocument.Parse(CryptoBox.Decrypt(envelope, session.Key));
        if (!doc.RootElement.TryGetProperty("confirm", out var confirm) || confirm.GetBoolean() != true)
            return Results.BadRequest(new ApiError("Richiesta di chiusura non valida."));
    }
    catch (Exception ex) when (ex is FormatException or System.Security.Cryptography.CryptographicException or JsonException or InvalidOperationException)
    { return Results.BadRequest(new ApiError("Busta di chiusura non valida.")); }

    sessions.TryRemove(envelope.SessionId, out _);
    return Results.Ok(new { status = "closed" });
});

app.MapGet("/", () => Results.Ok(new { service = "FrigoTrack API", status = "running" }));
app.Run();

static string SafeFileName(string sensorId) =>
    string.Concat(sensorId.Where(c => char.IsLetterOrDigit(c) || c == '-' || c == '_'));

public sealed class SessionState(byte[] key)
{
    public byte[] Key { get; } = key;
}

public partial class Program { }
