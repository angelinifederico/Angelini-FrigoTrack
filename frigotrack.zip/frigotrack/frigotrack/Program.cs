using System.Numerics;
using System.Security.Cryptography;

BigInteger b = new BigInteger(
    RandomNumberGenerator.GetBytes(32),
    isUnsigned: true,
    isBigEndian: true
);

BigInteger B = BigInteger.ModPow(g, b, p);