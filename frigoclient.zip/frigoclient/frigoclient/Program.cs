using System.Numerics;
using System.Security.Cryptography;

// Parametri Diffie-Hellman
BigInteger p = BigInteger.Parse("...");
BigInteger g = new BigInteger(2);

// Generazione del segreto privato del client
byte[] randomBytes = RandomNumberGenerator.GetBytes(32);

BigInteger a = new BigInteger(
    randomBytes,
    isUnsigned: true,
    isBigEndian: true
);

// Calcolo della chiave pubblica A
BigInteger A = BigInteger.ModPow(g, a, p);

Console.WriteLine($"Chiave pubblica del client: {A}");