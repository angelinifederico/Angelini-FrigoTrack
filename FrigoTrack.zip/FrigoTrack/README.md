# FrigoTrack – Telemetria sicura per la catena del freddo

Progetto didattico C#/.NET 8 realizzato sulla traccia `5IB_Progetto_TEP.pdf`.

## Requisiti

- Visual Studio 2022 aggiornato (workload ASP.NET e sviluppo .NET).
- .NET 8 SDK.
- Connessione Internet al primo avvio per ripristinare i pacchetti NuGet.

## Aprire e avviare con Visual Studio

1. Estrarre lo ZIP in una cartella.
2. Aprire `FrigoTrack.sln` con Visual Studio.
3. Attendere il ripristino dei pacchetti NuGet.
4. Compilare la soluzione: **Compila > Compila soluzione**.
5. Impostare `FrigoTrack.Server` come progetto di avvio e avviarlo.
6. Avviare una seconda istanza di Visual Studio oppure, da terminale nella cartella del progetto, eseguire:
   `dotnet run --project src/FrigoTrack.Client -- --once`

Per avviare il simulatore in modo continuo (un invio ogni 5 secondi):
`dotnet run --project src/FrigoTrack.Client`

Per la demo della misura fuori schema:
`dotnet run --project src/FrigoTrack.Client -- --invalid --once`
La misura fuori intervallo viene bloccata dal client prima della cifratura, come richiesto dalla traccia.

## Avvio da terminale

Dalla cartella che contiene la soluzione:

```bash
dotnet restore
dotnet build
dotnet run --project src/FrigoTrack.Server
# In un secondo terminale:
dotnet run --project src/FrigoTrack.Client -- --once
# Test automatici:
dotnet test
```

Il server ascolta su `http://localhost:5080`. La pagina `/` restituisce lo stato del servizio.
Le misure sono salvate in file JSON nella cartella `data` accanto all'output del server.

## Struttura

- `src/FrigoTrack.Common`: modelli, Diffie-Hellman, derivazione chiave, AES-GCM e validatore JSON Schema.
- `src/FrigoTrack.Server`: API HTTP, sessioni concorrenti, salvataggio e allarmi.
- `src/FrigoTrack.Client`: simulatore di tre sensori.
- `schemas`: uno schema JSON separato per ciascun messaggio.
- `tests`: test automatici.

## Protocollo

| Endpoint | Metodo | Funzione |
|---|---|---|
| `/api/handshake` | POST | Riceve p, g e A; risponde con session_id e B |
| `/api/telemetry` | POST | Riceve una busta cifrata; valida e archivia la misura; restituisce ACK cifrato |
| `/api/readings` | POST | Riceve richiesta cifrata e restituisce letture cifrate |
| `/api/close` | POST | Verifica la richiesta cifrata e rimuove la sessione |

### Sequenza handshake

```mermaid
sequenceDiagram
    participant C as Client
    participant S as Server
    C->>S: POST /api/handshake (p, g, A) in chiaro
    S->>S: genera b e calcola B = g^b mod p
    S->>S: K = A^b mod p, derivazione SHA-256
    S-->>C: session_id, B
    C->>C: K = B^a mod p, derivazione SHA-256
    Note over C,S: Da questo punto i messaggi applicativi sono cifrati AES-256-GCM
    C->>S: POST /api/telemetry (session_id, nonce, ciphertext, tag)
    S->>S: decifra, verifica tag, valida JSON Schema
    S-->>C: ACK cifrato (+ eventuale allarme)
```

## Cifratura e sicurezza

- Il gruppo Diffie-Hellman è il MODP a 2048 bit, gruppo 14 di RFC 3526, con generatore 2.
- Client e server generano esponenti casuali indipendenti.
- Il segreto DH viene sottoposto a SHA-256 per ottenere una chiave AES da 256 bit.
- AES-GCM autentica il contenuto. Il nonce casuale (12 byte) e il tag (16 byte) vengono trasmessi in Base64 insieme al ciphertext.
- `session_id` viene usato anche come AAD (Additional Authenticated Data), quindi è autenticato.
- Le chiavi sono conservate solo in memoria sul server e rimosse alla chiusura della sessione.
- Il server decifra e verifica il tag prima di validare e processare il messaggio.

## Schemi JSON

Gli schemi sono in `schemas/`: handshake request/response, telemetry, readings request/response, error ed envelope. Gli schemi della telemetria applicano pattern, enum, range numerici, required e `additionalProperties: false`.

## Intervalli di allarme adottati

Valori dimostrativi, configurabili nel server:
- `pharma`: 2–8 °C.
- `food`: 0–8 °C.
- `frozen`: temperatura massima -18 °C.

La traccia indica esplicitamente l'esempio farmaceutico 2–8 °C; gli altri due intervalli sono scelte dimostrative da concordare con il docente.

## Test

Il progetto include test per:
1. handshake Diffie-Hellman e uguaglianza del segreto;
2. cifratura e decifratura di un messaggio;
3. rifiuto di una busta manomessa;
4. accettazione di una telemetria valida;
5. rifiuto di temperatura fuori intervallo dello schema;
6. risposta 401 per sessione inesistente.

## Limiti noti e relazione tecnica

Questo è un prototipo didattico, non un sistema pronto per la produzione.

1. **HTTP senza TLS:** il contenuto applicativo è cifrato, ma handshake, `session_id`, indirizzi e metadati restano osservabili. Diffie-Hellman non autenticato è vulnerabile a un attacco man-in-the-middle: in produzione occorrerebbe autenticare le identità (certificati o firme) e usare TLS.
2. **Gestione sessioni:** le chiavi sono in memoria; un riavvio del server invalida tutte le sessioni. Non è implementata una scadenza automatica.
3. **Persistenza:** i file JSON sono adatti alla demo, non a carichi elevati o scritture distribuite.
4. **Gruppo e derivazione:** viene usato un gruppo noto e SHA-256 come derivazione essenziale per l'esercizio; in produzione si userebbe una KDF dedicata (HKDF) con salt e contesto.
5. **Replay:** AES-GCM protegge integrità e autenticità, ma il prototipo non mantiene un contatore anti-replay. Un messaggio valido catturato potrebbe essere ritrasmesso.
6. **Identità sensori:** il progetto non prevede autenticazione forte del sensore oltre alla sessione DH.

## Nota per la discussione

Saper spiegare:
- perché il client invia A e non il segreto a;
- perché il server e il client ottengono lo stesso K;
- perché il nonce non deve essere riutilizzato con la stessa chiave;
- differenza tra cifratura e autenticazione del tag GCM;
- perché il server verifica il tag prima di validare il JSON;
- perché il DH non autenticato non impedisce un MITM.
