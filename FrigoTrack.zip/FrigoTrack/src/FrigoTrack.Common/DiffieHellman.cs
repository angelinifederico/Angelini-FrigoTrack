using System.Numerics;
using System.Security.Cryptography;
using System.Text;

namespace FrigoTrack.Common;

public static class DiffieHellman
{
    // Gruppo MODP a 2048 bit, RFC 3526 gruppo 14; generatore 2.
    private const string PrimeHex =
        "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1" +
        "29024E088A67CC74020BBEA63B139B22514A08798E3404DD" +
        "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245" +
        "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED" +
        "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D" +
        "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F" +
        "83655D23DCA3AD961C62F356208552BB9ED529077096966D" +
        "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B" +
        "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9" +
        "DE2BCBF6955817183995497CEA956AE515D2261898FA0510" +
        "15728E5A8AACAA68FFFFFFFFFFFFFFFF";

    public static readonly BigInteger P = ParseHex(PrimeHex);
    public static readonly BigInteger G = new(2);

    public static (BigInteger Private, BigInteger Public) CreateKeyPair()
    {
        byte[] random = RandomNumberGenerator.GetBytes(32);
        BigInteger secret = new(random, isUnsigned: true, isBigEndian: true);
        if (secret < 2) secret += 2;
        return (secret, BigInteger.ModPow(G, secret, P));
    }

    public static BigInteger ComputeSharedSecret(BigInteger peerPublic, BigInteger privateKey)
    {
        if (peerPublic <= 1 || peerPublic >= P - 1)
            throw new CryptographicException("Chiave pubblica DH non valida.");
        return BigInteger.ModPow(peerPublic, privateKey, P);
    }

    public static byte[] DeriveAesKey(BigInteger sharedSecret)
    {
        byte[] raw = sharedSecret.ToByteArray(isUnsigned: true, isBigEndian: true);
        return SHA256.HashData(raw);
    }

    public static string PDecimal => P.ToString();
    public static string GDecimal => G.ToString();

    public static BigInteger ParseDecimal(string value)
    {
        if (!BigInteger.TryParse(value, out var n)) throw new FormatException("Numero DH non valido.");
        return n;
    }

    private static BigInteger ParseHex(string hex) =>
        new(Convert.FromHexString(hex), isUnsigned: true, isBigEndian: true);
}
